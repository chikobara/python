## Summary

* OS: { type-or-version }
* Bug fix: { yes/no }
* Type: { core, doc, performance, scripts, tests, wheels, new-api }
* Fixes: { comma-separated list of issues fixed by this PR, if any }

## Description

{{{
  A clear explanation of your bugfix or enhancement. Please read the contributing guidelines before submit:
  https://github.com/giampaolo/psutil/blob/master/CONTRIBUTING.md
}}}
